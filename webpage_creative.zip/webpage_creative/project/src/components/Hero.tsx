import React, { useEffect, useState } from 'react';
import { useTextAnimation } from '../hooks/useTextAnimation';
import { ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  const [loaded, setLoaded] = useState(false);
  const animatedHello = useTextAnimation('Hello');
  const animatedWorld = useTextAnimation('World');
  
  useEffect(() => {
    // Trigger animation after component mounts
    setLoaded(true);
  }, []);

  const scrollToContent = () => {
    const contentSection = document.getElementById('about');
    if (contentSection) {
      contentSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden">
      <div className={`transition-all duration-1000 ease-out transform ${loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        <h1 className="text-5xl md:text-7xl lg:text-9xl font-bold text-center">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500">
            {animatedHello}
          </span>
          <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500">
            {animatedWorld}
          </span>
        </h1>
        
        <p className={`mt-6 text-lg md:text-xl text-gray-600 dark:text-gray-300 text-center max-w-md mx-auto transition-all duration-1000 delay-500 ${loaded ? 'opacity-100' : 'opacity-0'}`}>
          A creative exploration of web design with modern techniques and animations.
        </p>
      </div>

      <button 
        onClick={scrollToContent}
        className={`absolute bottom-12 animate-bounce transition-all duration-1000 delay-1000 ${loaded ? 'opacity-100' : 'opacity-0'}`}
        aria-label="Scroll down"
      >
        <ArrowDown className="h-8 w-8 text-gray-600 dark:text-gray-300" />
      </button>
    </section>
  );
};

export default Hero;