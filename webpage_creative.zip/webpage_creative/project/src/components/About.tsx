import React from 'react';
import { Code, Layout, Zap } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    {
      icon: <Code className="h-10 w-10 text-blue-500" />,
      title: 'Modern Code',
      description: 'Built with the latest HTML5, CSS3, and JavaScript technologies for optimal performance.'
    },
    {
      icon: <Layout className="h-10 w-10 text-purple-500" />,
      title: 'Responsive Design',
      description: 'Perfectly adapts to any screen size or device for consistent user experience.'
    },
    {
      icon: <Zap className="h-10 w-10 text-pink-500" />,
      title: 'Fast & Interactive',
      description: 'Optimized for speed with smooth animations and interactive elements.'
    }
  ];

  return (
    <section id="about" className="py-24 px-4 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800 dark:text-white">About This Project</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            This "Hello World" page showcases modern web development techniques with a focus on interactive design and smooth animations.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white dark:bg-gray-900 p-8 rounded-xl shadow-md transition-all duration-300 hover:shadow-lg transform hover:-translate-y-1"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white">{feature.title}</h3>
              <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;